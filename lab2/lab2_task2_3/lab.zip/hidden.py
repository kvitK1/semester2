# Keep this file separate

# https://apps.twitter.com/
# Create new App and get the four strings

def oauth():
    return {"consumer_key": "0PlKlKMbNYWL9UeVuC6DPxX4B",
            "consumer_secret": "dpvpCGjA9udpjsPkCVfdxZhmAOLMXFeZcZEVLbH3usRiv8fHfN",
            "token_key": "963011359737774080-D73fzqJ2jocOftSRejq7tJz2gn4Xa2n",
            "token_secret": "KJ9zSSyrJsYLidt7PQTyPeAqZvrB92bxWwlzv7Ma8hMcG"}
